package program2;

public class Library {
    private static int n; //number of nodes
    private static int d[][]; //distance matrix
    
    public static void LoadD(String path) {
        java.io.File file = new java.io.File(path);
        
        try (java.util.Scanner input = new java.util.Scanner(file);) {
            n = input.nextInt();
            d = new int[n][n];
            for(int i = 0; i < n; i++) {
                for(int j = 0; j < n; j++) {
                    d[i][j] = input.nextInt();
                }
            }
        }
        catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }
    
    // 10 September 2019, 05:35
    public static int[] SymmetricTSP() {
        int s[] = NearestNeighborAlgorithm();
        int distance[] = {GetDistance(s)};
        
        int a = 100;
        int b = 20;
                
        s = FasterShahabHeuristicAlgorithm(s, a, distance); //perlu
        s = FasterReverseHeuristicAlgorithm(s, 100, distance); //perlu

        s = FasterShahabHeuristicAlgorithm(s, a, distance); //perlu
        s = FasterReverseHeuristicAlgorithm(s, 100, distance);

        s = FasterShahabHeuristicAlgorithm1_5(s, b, distance); //perlu
        s = FasterReverseHeuristicAlgorithm(s, 100, distance);

        s = FasterShahabHeuristicAlgorithm2_0(s, b, distance); //perlu
        s = FasterReverseHeuristicAlgorithm(s, 100, distance); //perlu

        s = FasterShahabHeuristicAlgorithm2_5(s, b, distance); //perlu
        s = FasterReverseHeuristicAlgorithm(s, 100, distance);

        s = FasterShahabHeuristicAlgorithm3_0(s, b, distance); //perlu
        s = FasterReverseHeuristicAlgorithm(s, 100, distance); //perlu

        s = FasterShahabHeuristicAlgorithm3_5(s, b, distance); //perlu
        s = FasterReverseHeuristicAlgorithm(s, 100, distance); //perlu
        
        return s;
    }
    
    // 21 Agustus 2019, 22:45
    public static int[] NearestNeighborAlgorithm() {
        int permutation[] = new int[n];
        for(int i = 0; i < n; i++) {
            permutation[i] = i;
        }
        
        int a[] = new int[n];
        int index = (int)(Math.random()*(n));
        a[0] = permutation[index];
        SwapOperator2(permutation, index, n-1);
        
        for(int i = 1; i < n; i++) {
            // mencari titik yang paling dekat dengan a[i-1]
            index = 0;
            int min1 = d[a[i-1]][permutation[0]];
            for(int j = 1; j < n-i; j++) {
                int min2 = d[a[i-1]][permutation[j]];
                if(min2 < min1) {
                    index = j;
                    min1 = min2;
                }
            }
            
            a[i] = permutation[index];
            SwapOperator2(permutation, index, n-1-i);
        }
        
        return a;
    }
    
    // 19 Agustus 2019, 16:00
    public static void SwapOperator2(int a[], int i, int j) {
        int dummy = a[i];
        a[i] = a[j];
        a[j] = dummy;
    }
    
    public static int GetDistance(int[] a) {
        int n = a.length;
        int result = 0;
        for(int i = 1; i < n; i++) {
            result += d[a[i-1]][a[i]];
        }
        result += d[a[n-1]][a[0]];
        return result;
    }
    
    // 10 September 2019, 05:40
    public static int[] FasterShahabHeuristicAlgorithm(int a[], int max_iteration, int distance[]) {
        int K = (int)Math.sqrt(n) + 1;
        
        for(int i = 0; i < max_iteration; i++) {
            a = FasterShahabAlgorithm(a, K, distance);
        }
        
        return a;
    }
    
    // 21 Agustus 2019, 01:45
    public static int[] FasterShahabAlgorithm(int a[], int K, int distance[]) {
        for(int i = 0; i < n; i++) {
            a = FasterShahabOperator(a, i, K, distance);
        }
        return a;
    }
    
    // 21 Agustus 2019, 01:30
    public static int[] FasterShahabOperator(int a[], int index, int K, int distance[]) {
        int distance0 = distance[0];
        // buat b[] dan c[]
        // b[] adalah a[] setelah dikurangi elemen yang dibuang
        // c[] adalah elemen-elemen yang dibuang, sebanyak K, dimulai dari index
        int b[] = new int[n - K];
        for(int i = K; i < n; i++) {
            b[i-K] = a[(index+i)%n];
        }
        //Print(b);
        
        int c[] = new int[K];
        for(int i = 0; i < K; i++) {
            c[i] = a[(index+i)%n]; 
        }
        //Print(c);
        
        // distance1 adalah distance dari b[]
        int distance1 = distance0 + d[b[b.length-1]][b[0]] - d[b[b.length-1]][c[0]] - GetDistance(c) - d[c[c.length-1]][b[0]] + d[c[c.length-1]][c[0]];
        
        Shuffle(c);
        //Print(c);
        
        for(int i = 0; i < K; i++) {
            // untuk setiap c[i], mencari j terbaik
            // c[i] bisa diletakkan di posisi ke 1,2,..., b.length
            int s[] = new int[b.length];
            for(int j = 0; j < b.length; j++) {
                int e = b[j];
                int f = b[(j+1)%b.length];
                int g = c[i];
                // ef menjadi egf
                s[j] = - d[e][f] + d[e][g] + d[g][f];
            }
            int index_of_min_s = IndexOfMin(s);
            b = Add(b, c[i], index_of_min_s+1);
            //Print(b);
            distance1 = distance1 + s[index_of_min_s];
        }
        
        if(distance1 < distance0) {
            distance[0] = distance1;
            
            return b;
        }
        else {
            return a;
        }
    }
    
    // 19 Agustus 12:12
    public static void Shuffle(int b[]) {
        int n = b.length;
        // Shuffle the cards
        for (int i = 0; i < n; i++) {
            // Generate an index randomly
            int index = (int)(Math.random() * n);
            int temp = b[i];
            b[i] = b[index];
            b[index] = temp;
        }
    }
    
    public static int IndexOfMin(int a[]) {
        int index = 0;
        double min = a[0];
        for(int i = 1; i < a.length; i++) {
            if(min > a[i]) {
                min = a[i];
                index = i;
            }
        }
        return index;
    }
    
    public static int[] Add(int a[], int b, int position) {
        int[] c = new int[a.length+1];
        for(int i = 0; i < position; i++) {
            c[i] = a[i];
        }
        c[position] = b;
        for(int i = position+1; i < a.length+1; i++) {
            c[i] = a[i-1];
        }
        return c;
    }
    
    // 10 September 2019, 05:40
    public static int[] FasterReverseHeuristicAlgorithm(int a[], int max_iteration, int distance[]) {
        for(int i = 0; i < max_iteration; i++) {
            int distance1 = distance[0];
            VoidReverseAlgorithm(a, distance);
            if(distance[0] == distance1) {
                break;
            }
        }
        return a;
    }
    
    // 21 Agustus 2019, 00:45
    public static void VoidReverseAlgorithm(int b[], int distance[]) {
        int d0 = distance[0];
        
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                int k = Math.min(i, j);
                int l = Math.max(i, j);
                if(k != l && l-k != n-2 && l-k != n-1) {
                    int p = b[(k-1+n)%n];
                    int q = b[k];
                    int r = b[l];
                    int s = b[(l+1)%n];
                    int d1 = d0 - d[p][q] - d[r][s] + d[p][r] + d[q][s];
                    
                    if(d1 < d0) {
                        VoidReverseOperator(b, k, l);
                        d0 = d1;
                    }
                }
            }
        }
        distance[0] = d0;
    }
    
    // 21 Agustus 2019, 00:30
    public static void VoidReverseOperator(int a[], int pos1, int pos2) {
        int k = Math.min(pos1, pos2);
        int l = Math.max(pos1, pos2);
        
        // yang direverse adalah yang sedikit
        int n1 = l - k + 1;
        int n2 = n - n1;
        if(n1 < n2) {
            for(int i = 0; i < n1/2; i++) {
                int dummy = a[k + i];
                a[k + i] = a[l - i];
                a[l - i] = dummy;
            }
        }
        else {
            for(int i = 0; i < n2/2; i++) {
                int x = (k-i-1+n)%n;
                int y = (l+i+1)%n;
                int dummy = a[x];
                a[x] = a[y];
                a[y] = dummy;
            }
        }
    }
    
    // 10 September 2019, 05:45
    public static int[] FasterShahabHeuristicAlgorithm1_5(int a[], int max_iteration, int distance[]) {
        int K = (int)(Math.sqrt(n)*1.5);
        
        for(int i = 0; i < max_iteration; i++) {
            a = FasterShahabAlgorithm(a, K, distance);
        }
        
        return a;
    }
    
    // 10 September 2019, 05:45
    public static int[] FasterShahabHeuristicAlgorithm3_5(int a[], int max_iteration, int distance[]) {
        int K = (int)(Math.sqrt(n)*3.5);
        
        for(int i = 0; i < max_iteration; i++) {
            a = FasterShahabAlgorithm(a, K, distance);
        }
        
        return a;
    }
        
    // 10 September 2019, 05:45
    public static int[] FasterShahabHeuristicAlgorithm3_0(int a[], int max_iteration, int distance[]) {
        int K = (int)(Math.sqrt(n)*3);
        
        for(int i = 0; i < max_iteration; i++) {
            a = FasterShahabAlgorithm(a, K, distance);
        }
        
        return a;
    }
    
    // 10 September 2019, 05:45
    public static int[] FasterShahabHeuristicAlgorithm2_5(int a[], int max_iteration, int distance[]) {
        int K = (int)(Math.sqrt(n)*2.5);
        
        for(int i = 0; i < max_iteration; i++) {
            a = FasterShahabAlgorithm(a, K, distance);
        }
        
        return a;
    }
    
    // 10 September 2019, 05:45
    public static int[] FasterShahabHeuristicAlgorithm2_0(int a[], int max_iteration, int distance[]) {
        int K = (int)(Math.sqrt(n)*2);
        
        for(int i = 0; i < max_iteration; i++) {
            a = FasterShahabAlgorithm(a, K, distance);
        }
        
        return a;
    }
    
    public static void Print(int a[]) {
        for(int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }
}